<?php
class modele
{
	private $unPdo, $uneTable;

	public function __construct ($server, $bdd, $user, $mdp)
	{
		try {
			$this->unPdo = new PDO("mysql:host=".$server.";dbname=".$bdd,$user,$mdp);
		}
		catch (PDOException $exp)
		{
			echo "Erreur de connexion !";
		}
	}
	public function setTable ($uneTable)
	{
		$this->uneTable = $uneTable;
	}
	public function selectAll ()
	{
		if($this->unPdo != null)
		{
			$requete = "select * from ".$this->uneTable.";";
			$select = $this->unPdo->prepare($requete);
			$select ->execute ();
			return $select->fetchAll();
		}else return null;
	}
	public function insert ($tab)
	{
		if ($this->unPdo != null)
		{
			$champs = array();
			$donnees = array();
			foreach ($tab as $cle=>$valeur)
			{
				$champs[]= ":".$cle;
				$donnees[":".$cle] = $valeur;
			}
			$lesChamps = implode(",", $champs);
			$requete ="insert into ".$this->uneTable." values (null, ".$lesChamps.");";
			$insert = $this->unPdo->prepare ($requete);
			$insert->execute ($donnees);
		}else{
			return null;
		}
	}
	public function selectWhere ($where)
	{
		if ($this->unPdo !=null)
		{
			$clauses = array();
			$donnees = array();
			foreach ($where as $cle=>$valeur)
			{
				$clauses [] = $cle."=:".$cle;
				$donnees[":".$cle] = $valeur;
			}
			$lesClauses = implode(" and ", $clauses);
			$requete ="select * from ".$this->uneTable." where ".$lesClauses.";";
			$select = $this->unPdo->prepare($requete);
			$select->execute ($donnees);
			return $select->fetch();

		}else {
			return null;
		}
	}
	
}

?>