drop database if exists mabase;
create database mabase;
	use mabase;

create table utilisateur (
	idutil int(5) not null auto_increment,
	nom varchar (50),
	prenom varchar(50),
	email varchar (100),
	mdp varchar(200),
	typecompte varchar(40),
	primary key(idutil)
);

insert into utilisateur values 
	(null, "tran", "loic", "t@gmail.com", "123", "admin");