
<form method ="post" action ="">
	<table border =0>
		<tr> <td> email : </td>
			<td> <input type = "text" name ="email"> </td>
		<tr> <td> mdp : </td>
			<td> <input type = "password" name ="mdp"> </td>
		<td> <input type = "reset" name ="Annuler" value="Annuler"> </td>
		<input type = "submit" class="btn btn-block" name ="Seconnecter" value="Se connecter"> </td>
	</tr>
</table>
</form>


<h2> Inscription d'un nouvel user </h2>
<form method ="post" action ="">
	<table border =0>
		<tr> <td> Nom : </td>
			<td> <input type = "text" name ="nom"> </td>
		<tr> <td> Prénom : </td>
			<td> <input type = "text" name ="prenom"> </td>
		<tr> <td> Email : </td>
			<td> <input type = "text" name ="email"> </td>
		<tr> <td> Mot de passe  : </td>
			<td> <input type = "password" name ="mdp"> </td>
		<tr> <td> Confirmation : </td>
			<td> <input type = "password" name ="confirm"> </td>
		<tr> <td> Type Compte : </td>
			<td> <select name="typecompte">
				<option value="admin"> Administrateur </option>
				<option value="user"> Utilisateur </option>
				<option value="autre"> Autre </option>
			</select>
		</td>

		<td> <input type = "reset" name ="Annuler" value="Annuler"> </td>
		<td> <input type = "submit" name ="Valider" value="Valider"> </td>
</tr>
</table>
</form>
