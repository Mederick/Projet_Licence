<?php 
	require_once("controlleur/controlleur.class.php");
	require_once("controlleur/utilisateur.class.php");
	?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
	<body>
		<center>
			<h2> Connexion</h2>

			<?php
				//instanciation du controlleur 
			$unC = new  Controlleur("localhost", "mabase", "root", "root");
			//choix de la table 
			$unC->setTable ("utilisateur");
			//recuperation des données 
			$resultats = $unC->selectAll();
			$lesUtilisateurs = array();
			foreach ($resultats as $unRes)
			{
				//instanciation de la classe utilisateur 
				$unUser = new utilisateur ();
				//on renseingne l'utilisateur 
				$unUser->renseigner($unRes);
				//insertion de l'user dans array user
				$lesUtilisateurs[] =$unUser;
			}
			//appel de la vue 
			include ("vue/vue_select_utlisateur.php");

			include ("vue/vue_inscription_user.php");
			if(isset($_POST['Valider']))
			{
				//instanciation classe user 
				$unUser = new utilisateur();
				$unUser->renseigner($_POST);
				if($unUser->verif_mdp($_POST['confirm']))
				{
					$unC->insert($unUser->serialiser());
				}else 
				{
					echo "Echec d'insertion , verifier votre mot de passe !";
				}
			}

			if(isset($_POST["Seconnecter"]))
			{
				$where =array("email" =>$_POST['email'], "mdp" =>$_POST['mdp']);
					$resultat = $unC ->selectWhere($where);
					if(isset($resultat['email']))
					{
						echo "Vous etes connecter autant que ";
						echo $resultat['nom']." ".$resultat['prenom'];
						//construction de l'objet 
						$unUser = new utilisateur ();
						$unUser->renseigner ($resultat);
					}
					else 
					{
						echo "Veuillez verifier vos identifiants";
					}
			}


			?>
		</center>
	</body>
</html>