<?php
        class Utilisateur 
        {
                private $idutil, $nom, 
                $prenom, $email, $mdp ; 

                public function __construct()
                {
                        $this->idutil = 0; 
                        $this->nom = ""; 
                        $this->prenom = "";
                        $this->email= "";
                        $this->mdp = "";

                }

                public function renseigner($tab)
                {
                        if(isset($tab['idutil'])){
                                $this->idutil = $tab['idutil'];
                        }else{
                                $this->idutil =0;
                        }
                        $this->nom = $tab['nom']; 
                        $this->prenom = $tab['prenom'];
                        $this->email = $tab['email'];
                        $this->mdp = $tab['mdp'];
                        $this->typecompte = $tab['typecompte'];

                }

                public function afficher()
                {
                        return "<tr><td>".$this->idutil." </td>
                                                <td>".$this->nom." </td>
                                                <td>".$this->prenom." </td>
                                                <td>".$this->email." </td>
                                                <td>".$this->mdp."</td>
                                                <td>".$this->typecompte."</td></tr>";
                }
                public function verif_mdp ($unMdp)
                {
                        if (strlen($this->mdp)>=4 && $this->mdp == $unMdp)
                        {
                                return true;
                        }else{
                                return false;
                        }
                }
                public function serialiser ()
                {
                        $tab = array();
                        //$tab['idutil'] = $this->idutil;
                        $tab['nom'] = $this->nom;
                        $tab['prenom'] = $this->prenom;
                        $tab['email'] = $this->email;
                        $tab['mdp'] = $this->mdp;
                        $tab['typecompte'] = $this->typecompte;
                        return $tab;
                }



                public function getIdUtil()
                {
                        return $this->idutil; 

                }

                public function setIdUtil($idutil)
                {
                        $this->idutil = $idutil; 
                }

                public function getNom()
                {
                        return $this->nom; 

                }

                public function setNom($nom)
                {
                        $this->nom = $nom; 
                }

                public function getPrenom()
                {
                        return $this->prenom; 

                }

                public function setPrenom($prenom)
                {
                        $this->prenom = $prenom; 
                }

                public function getEmail()
                {
                        return $this->email; 

                }

                public function setEmail($email)
                {
                        $this->email = $email; 
                }

                public function getMdp()
                {
                        return $this->mdp; 

                }

                public function setMdp($mdp)
                {
                        $this->mdp = $mdp; 
                }

                public function getTypeCompte()
                {
                        return $this->typecompte; 

                }

                public function setTypeCompte($typecompte)
                {
                        $this->typecompte = $typecompte; 
                }
        }

?>