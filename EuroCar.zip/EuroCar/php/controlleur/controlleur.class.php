<?php
	require_once("modele/modele.class.php");

	class Controlleur 
	{
		private $unModele;

		public function __construct ($server, $bdd, $user, $mdp)
		{
			$this->unModele = new Modele ($server, $bdd, $user, $mdp);
		}
		public function setTable ($uneTable)
		{
			$this->unModele->setTable($uneTable);
		}
		public function selectAll()
		{
			return $this->unModele->selectAll();
		}
		public function insert ($tab)
		{
			$this->unModele->insert($tab);
		}
		public function selectWhere ($where)
		{
			return $this->unModele->selectWhere($where);
		}
	}

?>